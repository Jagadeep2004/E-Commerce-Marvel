import React, { useState } from 'react';
import { useCart } from '../contexts/CartContext';

// Import images from the assets/images directory
import ironmanImg from '../assets/images/ironman.jpg';
import captainImg from '../assets/images/captain.jpg';
import thorImg from '../assets/images/thor.jpg';
import blackpantherImg from '../assets/images/blackpanther.jpg';

const Products = () => {
  const { addToCart, cart } = useCart();
  const [filter, setFilter] = useState('all');

  // Sample product data with imported images
  const products = [
    {
      id: 1,
      name: "Iron Man Arc Reactor T-Shirt",
      price: 799,
      description: "Show your love for the genius billionaire with this premium Iron Man t-shirt featuring the iconic Arc Reactor design.",
      category: "avengers",
      imageUrl: ironmanImg // Using imported image
    },
    {
      id: 2,
      name: "Captain America Shield T-Shirt",
      price: 899,
      description: "Classic Captain America shield design on a comfortable cotton t-shirt. Perfect for fans of the First Avenger.",
      category: "avengers",
      imageUrl: captainImg // Using imported image
    },
    {
      id: 3,
      name: "Thor Ragnarok Battle T-Shirt",
      price: 749,
      description: "Inspired by Thor: Ragnarok, this t-shirt features the God of Thunder in his iconic battle stance with lightning effects.",
      category: "avengers",
      imageUrl: thorImg // Using imported image
    },
    {
      id: 4,
      name: "Black Panther Wakanda Forever T-Shirt",
      price: 849,
      description: "Celebrate Wakanda with this stylish Black Panther themed t-shirt featuring the iconic Wakanda Forever salute.",
      category: "wakanda",
      imageUrl: blackpantherImg // Using imported image
    }
  ];

  const filteredProducts = filter === 'all' 
    ? products 
    : products.filter(product => product.category === filter);

  const isInCart = (productId) => {
    return cart.some(item => item.id === productId);
  };

  return (
    <div className="products-page">
      <div className="products-banner">
        <h1>Marvel T-Shirts Collection</h1>
        <p>Find your favorite superhero tee</p>
      </div>

      <div className="products-container">
        <div className="filters">
          <button 
            className={`filter-btn ${filter === 'all' ? 'active' : ''}`}
            onClick={() => setFilter('all')}>
            All
          </button>
          <button 
            className={`filter-btn ${filter === 'avengers' ? 'active' : ''}`}
            onClick={() => setFilter('avengers')}>
            Avengers
          </button>
          <button 
            className={`filter-btn ${filter === 'wakanda' ? 'active' : ''}`}
            onClick={() => setFilter('wakanda')}>
            Wakanda
          </button>
        </div>

        <div className="products-grid">
          {filteredProducts.map((product) => (
            <div key={product.id} className="product-card">
              <div className="product-image">
                <img src={product.imageUrl} alt={product.name} />
                <div className="product-overlay">
                  <button 
                    className="quick-add-btn" 
                    onClick={() => addToCart(product)}>
                    {isInCart(product.id) ? 'Add More' : 'Quick Add'}
                  </button>
                </div>
              </div>
              <div className="product-info">
                <h3>{product.name}</h3>
                <p className="product-price">₹{product.price}</p>
                <p className="product-description">{product.description}</p>
                <button 
                  className="add-to-cart-btn" 
                  onClick={() => addToCart(product)}>
                  {isInCart(product.id) ? 'Add More to Cart' : 'Add to Cart'}
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default Products;