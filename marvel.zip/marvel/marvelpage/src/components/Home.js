import React from 'react';
import { Link } from 'react-router-dom';

// Import images from the assets/images directory
import ironmanImg from '../assets/images/ironman.jpg';
import captainImg from '../assets/images/captain.jpg';
import blackpantherImg from '../assets/images/blackpanther.jpg';
import avengersImg from '../assets/images/avengers.jpg';
import spidermanImg from '../assets/images/spiderman.jpg';
import xmenImg from '../assets/images/xmen.jpg';

const Home = () => {
  return (
    <div className="home">
      <div className="hero">
        <div className="hero-content">
          <h1>Unleash Your <span className="hero-highlight">Super</span> Style</h1>
          <p>Experience the Marvel Universe with our exclusive t-shirt collection</p>
          <Link to="/products" className="cta-button">Shop Collection</Link>
        </div>
      </div>
      
      <div className="features">
        <div className="feature">
          <div className="feature-icon">🚚</div>
          <h3>Free Shipping</h3>
          <p>On orders above ₹999</p>
        </div>
        <div className="feature">
          <div className="feature-icon">🔄</div>
          <h3>Easy Returns</h3>
          <p>30-day return policy</p>
        </div>
        <div className="feature">
          <div className="feature-icon">💯</div>
          <h3>Authentic Products</h3>
          <p>100% genuine merchandise</p>
        </div>
        <div className="feature">
          <div className="feature-icon">🛡️</div>
          <h3>Secure Checkout</h3>
          <p>Safe & encrypted payments</p>
        </div>
      </div>
      
      <div className="bestsellers">
        <h2>Fan Favorites</h2>
        <div className="bestseller-grid">
          <div className="bestseller-item">
            <div className="bestseller-image">
              <img src={ironmanImg} alt="Iron Man T-Shirt" />
              <div className="bestseller-overlay">
                <Link to="/products" className="view-button">View Product</Link>
              </div>
            </div>
            <h3>Iron Man Graphic T-Shirt</h3>
            <p className="bestseller-price">₹799</p>
          </div>
          <div className="bestseller-item">
            <div className="bestseller-image">
              <img src={captainImg} alt="Captain America T-Shirt" />
              <div className="bestseller-overlay">
                <Link to="/products" className="view-button">View Product</Link>
              </div>
            </div>
            <h3>Captain America Shield T-Shirt</h3>
            <p className="bestseller-price">₹899</p>
          </div>
          <div className="bestseller-item">
            <div className="bestseller-image">
              <img src={blackpantherImg} alt="Black Panther T-Shirt" />
              <div className="bestseller-overlay">
                <Link to="/products" className="view-button">View Product</Link>
              </div>
            </div>
            <h3>Black Panther Wakanda Forever</h3>
            <p className="bestseller-price">₹849</p>
          </div>
        </div>
        <div className="view-all-container">
          <Link to="/products" className="view-all-button">View All Products</Link>
        </div>
      </div>
      
      <div className="categories">
        <h2>Shop by Character</h2>
        <div className="category-cards">
          <div className="category-card">
            <div className="category-image">
              <img src={avengersImg} alt="Avengers Collection" />
            </div>
            <h3>Avengers</h3>
            <Link to="/products" className="category-link">Explore</Link>
          </div>
          <div className="category-card">
            <div className="category-image">
              <img src={spidermanImg} alt="Spider-Man Collection" />
            </div>
            <h3>Spider-Man</h3>
            <Link to="/products" className="category-link">Explore</Link>
          </div>
          <div className="category-card">
            <div className="category-image">
              <img src={xmenImg} alt="X-Men Collection" />
            </div>
            <h3>X-Men</h3>
            <Link to="/products" className="category-link">Explore</Link>
          </div>
        </div>
      </div>
      
      <div className="newsletter">
        <div className="newsletter-content">
          <h2>Join Our Superhero Squad</h2>
          <p>Subscribe to get updates on new arrivals and special offers</p>
          <form className="newsletter-form">
            <input type="email" placeholder="Your email address" required />
            <button type="submit">Subscribe</button>
          </form>
        </div>
      </div>
    </div>
  );
};

export default Home;