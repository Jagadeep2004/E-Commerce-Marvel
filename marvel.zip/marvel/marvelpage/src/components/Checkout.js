import React, { useState } from 'react';
import { useCart } from '../contexts/CartContext';
import { useNavigate } from 'react-router-dom';

const Checkout = () => {
  const { cart, removeFromCart, updateQuantity, clearCart, cartTotal } = useCart();
  const navigate = useNavigate();
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    address: '',
    city: '',
    state: '',
    pincode: '',
    phone: ''
  });
  const [step, setStep] = useState(1);
  const [paymentMethod, setPaymentMethod] = useState('cod');
  
  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value
    });
  };
  
  const validateForm = () => {
    // Basic validation
    const { name, email, address, city, state, pincode, phone } = formData;
    return name && email && address && city && state && pincode && phone;
  };
  
  const handleSubmit = (e) => {
    e.preventDefault();
    
    if (step === 1) {
      if (validateForm()) {
        setStep(2);
        window.scrollTo(0, 0);
      } else {
        alert('Please fill all required fields');
      }
    } else {
      // Place order
      alert('Thank you for your order! Your Marvel merchandise is on the way!');
      clearCart();
      navigate('/');
    }
  };
  
  if (cart.length === 0) {
    return (
      <div className="empty-cart">
        <div className="empty-cart-content">
          <h2>Your cart is empty</h2>
          <p>Looks like you haven't added any products to your cart yet.</p>
          <button className="continue-shopping" onClick={() => navigate('/products')}>
            Browse Collection
          </button>
        </div>
      </div>
    );
  }
  
  return (
    <div className="checkout-page">
      <div className="checkout-steps">
        <div className={`step ${step >= 1 ? 'active' : ''}`}>
          <div className="step-number">1</div>
          <div className="step-text">Shipping</div>
        </div>
        <div className="step-line"></div>
        <div className={`step ${step >= 2 ? 'active' : ''}`}>
          <div className="step-number">2</div>
          <div className="step-text">Payment</div>
        </div>
      </div>
      
      <div className="checkout-container">
        {step === 1 ? (
          <div className="shipping-form">
            <h2>Shipping Information</h2>
            <form onSubmit={handleSubmit}>
              <div className="form-group">
                <label htmlFor="name">Full Name<span className="required">*</span></label>
                <input 
                  type="text" 
                  id="name" 
                  name="name" 
                  value={formData.name} 
                  onChange={handleInputChange}
                  placeholder="Enter your full name"
                  required 
                />
              </div>
              
              <div className="form-group">
                <label htmlFor="email">Email<span className="required">*</span></label>
                <input 
                  type="email" 
                  id="email" 
                  name="email" 
                  value={formData.email} 
                  onChange={handleInputChange}
                  placeholder="your.email@example.com"
                  required 
                />
              </div>
              
              <div className="form-group">
                <label htmlFor="address">Address<span className="required">*</span></label>
                <textarea 
                  id="address" 
                  name="address" 
                  value={formData.address} 
                  onChange={handleInputChange}
                  placeholder="Enter your full address"
                  required 
                />
              </div>
              
              <div className="form-row">
                <div className="form-group">
                  <label htmlFor="city">City<span className="required">*</span></label>
                  <input 
                    type="text" 
                    id="city" 
                    name="city" 
                    value={formData.city} 
                    onChange={handleInputChange}
                    placeholder="Enter your city"
                    required 
                  />
                </div>
                
                <div className="form-group">
                  <label htmlFor="state">State<span className="required">*</span></label>
                  <input 
                    type="text" 
                    id="state" 
                    name="state" 
                    value={formData.state} 
                    onChange={handleInputChange}
                    placeholder="Enter your state"
                    required 
                  />
                </div>
              </div>
              
              <div className="form-row">
                <div className="form-group">
                  <label htmlFor="pincode">PIN Code<span className="required">*</span></label>
                  <input 
                    type="text" 
                    id="pincode" 
                    name="pincode" 
                    value={formData.pincode} 
                    onChange={handleInputChange}
                    placeholder="Enter your 6-digit pincode"
                    pattern="[0-9]{6}"
                    maxLength="6"
                    required 
                  />
                  <small className="form-helper">Enter a valid 6-digit pincode</small>
                </div>
                
                <div className="form-group">
                  <label htmlFor="phone">Phone<span className="required">*</span></label>
                  <input 
                    type="tel" 
                    id="phone" 
                    name="phone" 
                    value={formData.phone} 
                    onChange={handleInputChange}
                    placeholder="Enter your mobile number"
                    pattern="[0-9]{10}"
                    maxLength="10"
                    required 
                  />
                  <small className="form-helper">Enter a 10-digit mobile number</small>
                </div>
              </div>
              
              <button type="submit" className="place-order-btn">Continue to Payment</button>
            </form>
          </div>
        ) : (
          <div className="payment-form">
            <h2>Payment Method</h2>
            <form onSubmit={handleSubmit}>
              <div className="payment-options">
                <div className="payment-option">
                  <input 
                    type="radio" 
                    id="cod" 
                    name="payment" 
                    value="cod"
                    checked={paymentMethod === 'cod'}
                    onChange={() => setPaymentMethod('cod')}
                  />
                  <label htmlFor="cod">Cash on Delivery</label>
                </div>
                
                <div className="payment-option">
                  <input 
                    type="radio" 
                    id="upi" 
                    name="payment" 
                    value="upi"
                    checked={paymentMethod === 'upi'}
                    onChange={() => setPaymentMethod('upi')}
                  />
                  <label htmlFor="upi">UPI</label>
                </div>
                
                <div className="payment-option">
                  <input 
                    type="radio" 
                    id="card" 
                    name="payment" 
                    value="card"
                    checked={paymentMethod === 'card'}
                    onChange={() => setPaymentMethod('card')}
                  />
                  <label htmlFor="card">Credit/Debit Card</label>
                </div>
              </div>
              
              {paymentMethod === 'upi' && (
                <div className="upi-details">
                  <div className="form-group">
                    <label htmlFor="upiId">UPI ID<span className="required">*</span></label>
                    <input 
                      type="text" 
                      id="upiId" 
                      placeholder="yourname@upi"
                      required 
                    />
                  </div>
                </div>
              )}
              
              {paymentMethod === 'card' && (
                <div className="card-details">
                  <div className="form-group">
                    <label htmlFor="cardNumber">Card Number<span className="required">*</span></label>
                    <input 
                      type="text" 
                      id="cardNumber" 
                      placeholder="1234 5678 9012 3456"
                      maxLength="19"
                      required 
                    />
                  </div>
                  
                  <div className="form-row">
                    <div className="form-group">
                      <label htmlFor="expiry">Expiry Date<span className="required">*</span></label>
                      <input 
                        type="text" 
                        id="expiry" 
                        placeholder="MM/YY"
                        maxLength="5"
                        required 
                      />
                    </div>
                    
                    <div className="form-group">
                      <label htmlFor="cvv">CVV<span className="required">*</span></label>
                      <input 
                        type="password" 
                        id="cvv" 
                        placeholder="123"
                        maxLength="3"
                        required 
                      />
                    </div>
                  </div>
                  
                  <div className="form-group">
                    <label htmlFor="cardName">Name on Card<span className="required">*</span></label>
                    <input 
                      type="text" 
                      id="cardName" 
                      placeholder="John Doe"
                      required 
                    />
                  </div>
                </div>
              )}
              
              <div className="button-row">
                <button type="button" className="back-btn" onClick={() => setStep(1)}>
                  Back to Shipping
                </button>
                <button type="submit" className="place-order-btn">
                  Place Order
                </button>
              </div>
            </form>
          </div>
        )}
        
        <div className="cart-summary-container">
          <div className="cart-items">
            <h2>Order Summary</h2>
            {cart.map((item) => (
              <div key={item.id} className="cart-item">
                <div className="item-image">
                  <img src={item.imageUrl} alt={item.name} />
                </div>
                <div className="item-details">
                  <h3>{item.name}</h3>
                  <p className="item-price">₹{item.price}</p>
                  <div className="quantity-control">
                    <button onClick={() => updateQuantity(item.id, item.quantity - 1)}>-</button>
                    <span>{item.quantity}</span>
                    <button onClick={() => updateQuantity(item.id, item.quantity + 1)}>+</button>
                  </div>
                </div>
                <div className="item-total">
                  <p>₹{item.price * item.quantity}</p>
                  <button 
                    className="remove-item" 
                    onClick={() => removeFromCart(item.id)}>
                    <span>×</span>
                  </button>
                </div>
              </div>
            ))}
          </div>
          
          <div className="cart-summary">
            <div className="summary-row">
              <span>Subtotal:</span>
              <span>₹{cartTotal}</span>
            </div>
            <div className="summary-row">
              <span>Shipping:</span>
              <span>{cartTotal > 999 ? 'Free' : '₹100'}</span>
            </div>
            <div className="summary-row">
              <span>GST (18%):</span>
              <span>₹{Math.round(cartTotal * 0.18)}</span>
            </div>
            <div className="summary-row total">
              <span>Total:</span>
              <span>₹{cartTotal > 999 
                ? cartTotal + Math.round(cartTotal * 0.18) 
                : cartTotal + 100 + Math.round(cartTotal * 0.18)}</span>
            </div>
          </div>
          
          <div className="coupon-code">
            <input type="text" placeholder="Enter coupon code" />
            <button>Apply</button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Checkout;